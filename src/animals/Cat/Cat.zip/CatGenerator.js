// src/animals/CatGenerator.js

import * as THREE from 'three';
import { generateTorsoGeometry } from '../bodyParts/TorsoGenerator.js';
import { generateNeckGeometry } from '../bodyParts/NeckGenerator.js';
import { generateHeadGeometry } from '../bodyParts/HeadGenerator.js';
import { generateTailGeometry } from '../bodyParts/TailGenerator.js';
import { generateLimbGeometry } from '../bodyParts/LimbGenerator.js';
import { mergeGeometries } from '../../libs/BufferGeometryUtils.js';

import { CatBehavior } from './CatBehavior.js';

// NOTE: Replace 'lizard.png' with a 'cat_fur.jpg' or similar seamless noise texture
const furUrl = new URL('./cat_fur.jpg', import.meta.url).href;

// --- Texture Loading ---
const textureLoader = new THREE.TextureLoader();
// Add error handling fallback color if image missing
const furTexture = textureLoader.load(furUrl, undefined, undefined, (err) => {
    console.warn("Texture missing, using default color.");
});

furTexture.wrapS = THREE.RepeatWrapping;
furTexture.wrapT = THREE.RepeatWrapping;
furTexture.repeat.set(2, 2); 

/**
 * Procedurally generates a full skinned cat mesh.
 * Returns { mesh, behavior }
 */
export class CatGenerator {
  /**
   * @param {THREE.Skeleton} skeleton
   * @param {Object} options
   * @returns {{ mesh: THREE.SkinnedMesh, behavior: CatBehavior }}
   */
  static generate(skeleton, options = {}) {
    // Ensure all bones have their matrices up-to-date
    skeleton.bones.forEach(bone => bone.updateMatrixWorld(true));

    // === Generate all body part geometries ===
    
    // 1. TORSO: Cats have a deep chest and narrow waist (tapered)
    const torsoGeometry = generateTorsoGeometry(skeleton, {
      bones: options.torsoBones || ['spine_base', 'spine_mid', 'spine_neck', 'head'],
      // [Hips, Mid-Waist, Chest, NeckBase]
      radii: options.torsoRadii || [0.16, 0.14, 0.19, 0.13], 
      sides: options.torsoSides || 14
    });

    // 2. NECK: Shorter but thicker fur connection
    const neckGeometry = generateNeckGeometry(skeleton, {
      bones: options.neckBones || ['spine_neck', 'head'],
      sides: options.neckSides || 10
    });

    // 3. HEAD: Rounder, wider cheekbones
    const headGeometry = generateHeadGeometry(skeleton, {
      parentBone: options.headParentBone || 'head',
      radius: options.headRadius || 0.16 // Increased size for cat head
    });

    // 4. TAIL: Long, tapered, thicker base
    const tailGeometry = generateTailGeometry(skeleton, {
      bones: options.tailBones || ['tail_base', 'tail_mid', 'tail_tip'],
      sides: options.tailSides || 10,
      baseRadius: options.tailBaseRadius || 0.09,
      tipRadius: options.tailTipRadius || 0.04
    });

    // 5. FRONT LIMBS: Slender but defined
    const frontLeftLimb = generateLimbGeometry(skeleton, {
      bones: ['front_left_collarbone', 'front_left_upper_leg', 'front_left_lower_leg', 'front_left_paw'],
      radii: [0.10, 0.06, 0.04, 0.05], // [Shoulder, Upper, Lower, Paw]
      sides: 8
    });
    const frontRightLimb = generateLimbGeometry(skeleton, {
      bones: ['front_right_collarbone', 'front_right_upper_leg', 'front_right_lower_leg', 'front_right_paw'],
      radii: [0.10, 0.06, 0.04, 0.05],
      sides: 8
    });

    // 6. BACK LIMBS: Muscular thighs (hams)
    const backLeftLimb = generateLimbGeometry(skeleton, {
      bones: ['back_left_pelvis', 'back_left_upper_leg', 'back_left_lower_leg', 'back_left_paw'],
      radii: [0.12, 0.09, 0.05, 0.05], // Thicker thigh start
      sides: 8
    });
    const backRightLimb = generateLimbGeometry(skeleton, {
      bones: ['back_right_pelvis', 'back_right_upper_leg', 'back_right_lower_leg', 'back_right_paw'],
      radii: [0.12, 0.09, 0.05, 0.05],
      sides: 8
    });

    // === Merge ===
    const mergedGeometry = mergeGeometries([
      torsoGeometry,
      neckGeometry,
      headGeometry,
      tailGeometry,
      frontLeftLimb,
      frontRightLimb,
      backLeftLimb,
      backRightLimb
    ], false);

    // === Material ===
    const material = new THREE.MeshStandardMaterial({
      color: options.bodyColor || 0xddaa77,  // Default to an orange tabby color
      map: furTexture,
      side: THREE.DoubleSide,
      wireframe: !!options.debugWireframe,
      roughness: 0.8, // Fur is not shiny
      flatShading: false // Smooth shading looks better for soft animals
    });
    material.skinning = true;

    // === Mesh ===
    const mesh = new THREE.SkinnedMesh(mergedGeometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.bind(skeleton);

    // === Behavior ===
    const behavior = new CatBehavior(skeleton, mesh);

    return { mesh, behavior };
  }
}